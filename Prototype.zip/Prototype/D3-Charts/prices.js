var parseDate = d3.timeParse("%m/%d/%Y");


/*function dragged(d) {
  d3.select(this).attr( x = d3.event.x).attr(y = d3.event.y);
}				*/

		 
d3.csv("prices.csv")
    .row(function(d){ return {month: parseDate(d.month), price:Number(d.price.trim().slice(1))}; })
	.get(function(error,data){

      var height = 300;
      var width = 500;

      var max = d3.max(data,function(d){ return d.price; });
      var minDate = d3.min(data,function(d){ return d.month; });
      var maxDate = d3.max(data,function(d){ return d.month; });

      var y = d3.scaleLinear()
                  .domain([0,max])
                  .range([height,0]);
      var x = d3.scaleTime()
                  .domain([minDate,maxDate])
                  .range([0,width]);
      var yAxis = d3.axisLeft(y);
      var xAxis = d3.axisBottom(x);

      var svg = d3.select("body").append("svg").attr("height","100%").attr("width","100%");

      var margin = {left:50,right:50,top:40,bottom:0};

      var chartGroup = svg.append("g")
                  .attr("transform","translate("+margin.left+","+margin.top+")")
				  .call(d3.drag()
                     .on("drag", dragged));

      var line = d3.line()
                      .x(function(d){ return x(d.month); })
                      .y(function(d){ return y(d.price); });
		
		function dragged(d) {
               d3.select(this).attr("transform","translate("+d3.event.x+","+d3.event.y+")");
                         }
			  
      

      chartGroup.append("path").attr("d",line(data));
      chartGroup.append("g").attr("class","x axis").attr("transform","translate(0,"+height+")").call(xAxis);
      chartGroup.append("g").attr("class","y axis").call(yAxis);


     })
	 
